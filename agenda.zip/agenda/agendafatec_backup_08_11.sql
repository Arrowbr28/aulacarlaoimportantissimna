-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 08/11/2024 às 13:17
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agendafatec`
--
CREATE DATABASE IF NOT EXISTS `agendafatec` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `agendafatec`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ceps`
--

DROP TABLE IF EXISTS `ceps`;
CREATE TABLE `ceps` (
  `id` int(11) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `logradouro` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `uf` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `ceps`
--

INSERT INTO `ceps` (`id`, `cep`, `logradouro`, `bairro`, `cidade`, `uf`) VALUES
(1, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(2, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(3, '15906-562', 'Avenida fatec', 'fatec', 'Taquaritinga', 'SP'),
(5, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(6, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(7, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(8, '15906-762', 'Rua Profosser Paulao Lazaro Mendes', 'Jardim Micali', 'Taquaritinga', 'SP'),
(9, '15906-562', 'Avenida fatec', 'fatec', 'Taquaritinga', 'SP');

-- --------------------------------------------------------

--
-- Estrutura para tabela `enderecos`
--

DROP TABLE IF EXISTS `enderecos`;
CREATE TABLE `enderecos` (
  `id` int(11) NOT NULL,
  `cep` varchar(10) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `complemento` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `enderecos`
--

INSERT INTO `enderecos` (`id`, `cep`, `numero`, `complemento`) VALUES
(1, '15906-562', '224', 'casa do carlão'),
(2, '15906-562', '224', 'casa do carlão'),
(3, '15906-562', '224', 'casa do carlão'),
(4, '15906-562', '224', 'casa do carlão'),
(5, '15906-562', '224', 'casa do carlão'),
(6, '15906-562', '224', 'casa do carlão'),
(7, '15906-562', '224', 'casa do carlão'),
(8, '15906-562', '224', 'casa do carlão'),
(9, '15906-562', '224', 'casa do carlão'),
(10, '15906-562', '224', 'casa do carlão'),
(11, '15906-562', '224', 'casa do carlão'),
(12, '15906-562', '224', 'casa do carlão'),
(13, '15906-562', '224', 'casa do carlão'),
(14, '15906-562', '224', 'casa do carlão'),
(15, '15906-562', '224', 'casa do carlão'),
(16, '15906-562', '224', 'casa do carlão'),
(17, '15906-562', '224', 'casa do carlão'),
(18, '15906-000', '2241', 'casa do COMUNISTA'),
(19, '15906-562', '224', 'casa do carlão'),
(21, '15906-762', '224', 'casa do carlão');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pessoas`
--

DROP TABLE IF EXISTS `pessoas`;
CREATE TABLE `pessoas` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `observacao` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pessoas`
--

INSERT INTO `pessoas` (`id`, `nome`, `telefone`, `observacao`) VALUES
(1, 'Manoel Rodrigues', '(16)9.9999-2222', 'teste aleracao via route params'),
(8, 'Mariete Severo Oliveira', '(16) 9.8899-6969', ' Marieta severo, artista da globo.'),
(9, 'Luciana Ferrarezzi', '(16) 9.8899-1239', ' Diretora Fatec Taquaritinga.');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `ceps`
--
ALTER TABLE `ceps`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `enderecos`
--
ALTER TABLE `enderecos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `ceps`
--
ALTER TABLE `ceps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `enderecos`
--
ALTER TABLE `enderecos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de tabela `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
