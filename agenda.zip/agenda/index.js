const ui = document.querySelector('[data-js="pessoas"]');   

const getData = async () => {
    const response = await fetch('http://localhost/agenda/pessoas');
    return response.json();
}

// fetch é o data

// funcao map () puxa os dados no banco de dados ele pega o pessoa (nome da coluna) e faz o mapeamento do !array! de uma forma mais simples
const listaPessoas = pessoas => pessoas.map(pessoas => `
    <tr>
        <td>${pessoas.id}</td>
        <td>${pessoas.nome}</td>
        <td>${pessoas.telefone}</td>
        <td>${pessoas.observacao}</td>
        <td>${pessoas.id}</td>
    </tr>
`).join('')

// peguei o elemnto para renderizar o elemento dinamico transformou no codigo html 
// criou uma funcao para unir os dados em cima

const cargaDados = async () => {
    const data = await getData();
    const postTemplate = listaPessoas(data);
    ui.innerHTML = postTemplate;
}

cargaDados();

